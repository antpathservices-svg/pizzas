Pizza Deprizza · Biblioteca de iconos (UX Spec Power Apps v1.0)

51 iconos extraídos del prototipo (Lucide 0.487, trazo 2 px, cuadrícula 24 × 24).

svg/currentColor  Color heredado (para web o Figma)
svg/blanco        #FFFFFF  sobre fondos de marca (IconTile)
svg/naranja       #EA580C  acento sobre blanco
svg/cafe          #2D1B00  texto principal
png-96/*          PNG transparentes de 96 × 96 px por color
powerfx/          Tabla IconosDpz + función IconoDpz() para App.Formulas,
                  y una fórmula lista para pegar por icono (por-icono/)
logo/             Logo Pizza Deprizza (PNG 400 × 105)

Tamaños de uso: 16, 20, 24, 28, 40 px. Nunca escalar el trazo: el SVG lo ajusta solo.
